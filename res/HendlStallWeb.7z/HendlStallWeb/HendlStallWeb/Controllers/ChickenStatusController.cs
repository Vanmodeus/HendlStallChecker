﻿using DB;
using DB.Dto;
using HendlStallWeb.Models;
using HendlStallWeb.Models.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HendlStallWeb.Controllers
{
    public class ChickenController : Controller
    {
        public ActionResult Status()
        {
            using (var db = new HendlStallContext())
            {
                var chicks = Mappings.DtoDomainMapper.Map<List<ChickenDto>, List<ChickenDomain>>(db.Chicks.ToList());
                //var c = db.Chicks.ToList();
                //var l = db.Logs.ToList();
                //var i = db.Intrusions.ToList();

                var vm = new ChickenStatusViewModel(chicks);
                return View(vm);
            }
        }
    }
}