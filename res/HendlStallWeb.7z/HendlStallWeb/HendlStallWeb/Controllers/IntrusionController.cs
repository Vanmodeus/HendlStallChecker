﻿using DB;
using DB.Dto;
using HendlStallWeb.Models;
using HendlStallWeb.Models.Domain;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HendlStallWeb.Controllers
{
    public class IntrusionController : Controller
    {
        public ActionResult Index()
        {
            using (var db = new HendlStallContext())
            {
                var intrusions = Mappings.DtoDomainMapper.Map<List<IntrusionDto>, List<IntrusionDomain>>(db.Intrusions.OrderByDescending(d=>d.timestamp).ToList());
                return View(new IntrusionViewModel(intrusions));
            }
        }

        public ActionResult LoadImage(int id)
        {
            byte[] image = LoadImageFromRaspiFileSys(id);
            return File(image, "image/jpeg");
        }

        private byte[] LoadImageFromRaspiFileSys(int id)
        {
            using (var db = new HendlStallContext())
            {
                var intru = db.Intrusions.FirstOrDefault(i => i.id == id);
                if (intru == null)
                    return null;

                var intrusion = Mappings.DtoDomainMapper.Map<IntrusionDto, IntrusionDomain>(intru);
                return intrusion.image;
            }
        }

        public byte[] JpegImageToByteArray(System.Drawing.Image imageIn)
        {
            MemoryStream ms = new MemoryStream();
            imageIn.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
            return ms.ToArray();
        }

    }
}