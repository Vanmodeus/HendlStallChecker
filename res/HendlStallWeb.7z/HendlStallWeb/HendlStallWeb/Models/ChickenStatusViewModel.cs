﻿using HendlStallWeb.Models.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HendlStallWeb.Models
{
    public class ChickenStatusViewModel
    {
        public ChickenStatusViewModel(List<ChickenDomain> chicks)
        {
            Chicks = chicks;
        }

        public List<ChickenDomain> Chicks
        {
            get; set;
        }
    }
}