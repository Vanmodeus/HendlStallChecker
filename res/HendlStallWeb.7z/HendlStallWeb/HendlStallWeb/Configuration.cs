﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace HendlStallWeb
{
    public class Configuration
    {
        public static string RaspiIp
        {
            get
            {
                return ConfigurationManager.AppSettings["RaspiIP"];
            }
        }
    }
}