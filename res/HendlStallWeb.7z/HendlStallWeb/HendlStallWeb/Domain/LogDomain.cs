﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HendlStallWeb.Models.Domain
{
    public class LogDomain
    {
    }
}