﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HendlStallWeb.Models.Domain
{
    public class ChickenDomain
    {
        public long id
        {
            get; set;
        }
        public string rfidID
        {
            get; set;
        }
        public string name
        {
            get; set;
        }
        public bool inside
        {
            get; set;
        }

        public override string ToString()
        {
            return $"{id} | {rfidID} | {name} | {inside}";
        }
    }
}