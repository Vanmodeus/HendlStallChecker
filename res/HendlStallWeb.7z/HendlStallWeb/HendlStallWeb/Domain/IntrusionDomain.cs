﻿using DB.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HendlStallWeb.Models.Domain
{
    public class IntrusionDomain
    {
        public long id
        {
            get; set;
        }
        public IntrusionSeverity severity
        {
            get; set;
        }
        public DateTime timestamp
        {
            get; set;
        }
        public byte[] image
        {
            get; set;
        }
    }
}