﻿using AutoMapper;
using DB.Dto;
using HendlStallWeb.Models.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HendlStallWeb
{
    public class Mappings
    {
        public static IMapper DtoDomainMapper
        {
            get; set;
        }

        static Mappings()
        {
            CreateDtoDomainMapping();
        }

        private static void CreateDtoDomainMapping()
        {
            //configuration
            var config = new MapperConfiguration(cfg => {
                cfg.CreateMap<ChickenDto, ChickenDomain>();
                cfg.CreateMap<LogDto, LogDomain>();
                cfg.CreateMap<IntrusionDto, IntrusionDomain>();
            });
            config.AssertConfigurationIsValid();

            //mapping
            DtoDomainMapper = config.CreateMapper();
        }
   }
}