﻿
using EF6;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DB
{
    internal class ChickenMap : EntityTypeConfiguration<Chicken>
    {
        public ChickenMap()
        {
            ToTable("Chicken");
            this.Property(p => p.id)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            HasKey(k => k.id);
        }
    }
}
