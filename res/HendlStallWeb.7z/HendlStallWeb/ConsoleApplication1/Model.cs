﻿using DB;
using MySql.Data.Entity;
using System.Data.Common;
using System.Data.Entity;

namespace EF6
{
    // Code-Based Configuration and Dependency resolution
    [DbConfigurationType(typeof(MySqlEFConfiguration))]
    public class Parking : DbContext
    {
        public DbSet<Chicken> Chicks
        {
            get; set;
        }

        public Parking()
          : base()
        {

        }

        // Constructor to use on a DbConnection that is already opened
        public Parking(DbConnection existingConnection, bool contextOwnsConnection)
          : base(existingConnection, contextOwnsConnection)
        {

        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            //modelBuilder.Entity<Chicken>().MapToStoredProcedures();
            modelBuilder.Configurations.Add(new ChickenMap());
        }
    }

    public class Chicken
    {
        public long id
        {
            get; set;
        }
        public string rfidID
        {
            get; set;
        }
        public string name
        {
            get; set;
        }
        public bool inside
        {
            get; set;
        }

        public override string ToString()
        {
            return $"{id} | {rfidID} | {name} | {inside}";
        }
    }
}
