﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EF6
{
    class Example
    {

        public static void Main()
        {
            string connectionString = "server=192.168.8.101;port=3306;database=mus;uid=myuser;password=mypass";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                // Create database if not exists
                using (Parking contextDB = new Parking(connection, false))
                {
                    //contextDB.Database.CreateIfNotExists();
                }

                connection.Open();
                //MySqlTransaction transaction = connection.BeginTransaction();

                try
                {
                    // DbConnection that is already opened
                    using (Parking context = new Parking(connection, false))
                    {

                        // Interception/SQL logging
                        context.Database.Log = (string message) => {
                            Console.WriteLine(message);
                        };

                        // Passing an existing transaction to the context
                        //context.Database.UseTransaction(transaction);

                        // DbSet.AddRange
                        //List<Chicken> cars = new List<Chicken>();

                        //cars.Add(new Chicken {  id = 99, inside = false, name = "karl", rfidID="asdf" });

                        //context.Chicks.AddRange(cars);

                        //context.SaveChanges();

                        var chicks = context.Chicks.ToList();
                        foreach (var item in chicks)
                        {
                            Console.WriteLine(item);
                        }

                        //context.Chicks.Add(new Chicken(){ inside = true, id = -1, name = "Bertl", rfidID = "rfid" });

                        //context.SaveChanges();
                    }

                    //transaction.Commit();
                }
                catch
                {
                    //transaction.Rollback();
                    throw;
                }
            }
        }
    }
}
