﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DB.Dto
{
    public class ChickenDto
    {
        public long id
        {
            get; set;
        }
        public string rfidID
        {
            get; set;
        }
        public string name
        {
            get; set;
        }
        public bool inside
        {
            get; set;
        }

        public override string ToString()
        {
            return $"{id} | {rfidID} | {name} | {inside}";
        }
    }
}
