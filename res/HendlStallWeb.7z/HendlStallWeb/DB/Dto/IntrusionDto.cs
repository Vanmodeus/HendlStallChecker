﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DB.Dto
{
    public class IntrusionDto
    {
        public long id
        {
            get; set;
        }
        public IntrusionSeverity severity
        {
            get; set;
        }
        public DateTime timestamp
        {
            get; set;
        }
        public byte[] image
        {
            get; set;
        }
    }

    public enum IntrusionSeverity
    {
        WARNING_UNDEFINED, SEVERE_CARNIVORE, CRITICAL_SPECIFIC
    }
}
