﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DB.Dto
{
    public class LogDto
    {
        public long id
        {
            get; set;
        }
        public DateTime timestamp
        {
            get; set;
        }
        public ChickenDto Chick
        {
            get; set;
        }
    }
}
