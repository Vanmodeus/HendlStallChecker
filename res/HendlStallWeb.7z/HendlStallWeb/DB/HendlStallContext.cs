﻿using DB;
using DB.Dto;
using MySql.Data.Entity;
using System.Data.Common;
using System.Data.Entity;


namespace DB
{
    [DbConfigurationType(typeof(MySqlEFConfiguration))]
    public class HendlStallContext : DbContext
    {
        public HendlStallContext() : base("name=HendlStallDb")
        {
            //Database.SetInitializer<HendlStallContext>(new CreateDatabaseIfNotExists<HendlStallContext>());
        }


        // Constructor to use on a DbConnection that is already opened
        public HendlStallContext(DbConnection existingConnection, bool contextOwnsConnection)
          : base(existingConnection, contextOwnsConnection)
        {

        }

        public DbSet<ChickenDto> Chicks
        {
            get; set;
        }

        public DbSet<LogDto> Logs
        {
            get; set;
        }

        public DbSet<IntrusionDto> Intrusions
        {
            get; set;
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Configurations.Add(new ChickenMap());
            modelBuilder.Configurations.Add(new LogMap());
            modelBuilder.Configurations.Add(new IntrusionMap());
        }
    }
}
