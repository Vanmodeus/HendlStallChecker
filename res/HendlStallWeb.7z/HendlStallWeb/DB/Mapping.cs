﻿using DB;
using DB.Dto;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DB
{
    internal class ChickenMap : EntityTypeConfiguration<ChickenDto>
    {
        public ChickenMap()
        {
            ToTable("Chicken");
            this.Property(p => p.id)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            HasKey(k => k.id);
        }
    }

    internal class LogMap : EntityTypeConfiguration<LogDto>
    {
        public LogMap()
        {
            ToTable("Log");
            HasKey(k => k.id);
            HasRequired(l => l.Chick)
                .WithMany()
                .Map(d => d.MapKey("idChicken"));
        }
    }
    internal class IntrusionMap : EntityTypeConfiguration<IntrusionDto>
    {
        public IntrusionMap()
        {
            ToTable("Intrusion");
            this.Property(p => p.id)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            HasKey(k => k.id);
        }
    }
}
